using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Nakama;
using TMPro;
using UnityEngine.Tilemaps;
public class NakamaManagerScript : MonoBehaviour {

  private const string Scheme = "http";
  private const string Host = "127.0.0.1";
  private const int Port = 7350;
  private const string ServerKey = "defaultkey";

  private IClient client;
  private ISession session;
  private ISocket socket;
  public bool end = false;
  private string ticket;
  private bool matchFound = false, searching = true;
  private string winnerPlayer;
  private int playerNum, playerTurn;
  public TMP_Text playerNumText, winnerText;
  public GameObject grid, canvas, endGameCanvas;
  public Tilemap tilemap;
  public Tile[] tiles; // Tile objelerini tutacak dizi
  private int[,] matrix = new int[6, 8]; // Matris
  string matchId;
  public class PositionState
{
    public int x;
    public int y;
};

  async void Start() {
    for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                matrix[i, j] = 0;
            }
        }
    CreateGameBoard();
    var client = new Nakama.Client("http", "127.0.0.1", 7350, "defaultkey", UnityWebRequestAdapter.Instance);
    session = await client.AuthenticateDeviceAsync(SystemInfo.deviceUniqueIdentifier);
    socket = client.NewSocket();

    bool appearOnline = true;
    await socket.ConnectAsync(session, appearOnline);
    
    Debug.Log("session: " + session);
    Debug.Log("socket: " + socket);

    socket.ReceivedMatchmakerMatched += OnReceivedMatchmakerMatched;
   var enc = System.Text.Encoding.UTF8;
   socket.ReceivedMatchState += newState =>
{
    var content = enc.GetString(newState.State);
    if(newState.OpCode == 1111){
      playerNum = int.Parse(content);
    }else if(newState.OpCode == 1){

      content = content.Replace("[", "").Replace("]", "").Replace(",", "");
      for(int i=0; i<6; i++)
        for(int j = 0; j<8; j++){
          matrix[i, j] = int.Parse(content[0].ToString());
          content = content.Substring(1);
        }
    }else if(newState.OpCode == 2){
      playerTurn = int.Parse(content);
    }else if(newState.OpCode == 88){
      end = true;
      winnerPlayer = content;
    }

    };

  }
  void Update(){
    CreateGameBoard();
    if(matchFound){
      if(searching){
        searching = false;
        canvas.SetActive(false);
        grid.SetActive(true);
        playerNumText.SetText("Player "+playerNum);
      }
      if (Input.GetMouseButtonDown(0))
              {
                  Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                  Vector3Int cellPosition = tilemap.WorldToCell(mouseWorldPos);
                  
                  if(playerTurn == playerNum && tilemap.HasTile(cellPosition) && end==false)
                  {   cellPosition.x += 4;
                  cellPosition.y *= -1;
                  cellPosition.y += 3;
                      if(matrix[cellPosition.y, cellPosition.x]==0 || (playerNum == 1 && matrix[cellPosition.y,cellPosition.x]<4) || (playerNum == 2 && matrix[cellPosition.y,cellPosition.x]>3)){
                      Debug.Log("Tıklanan Nokta (Tilemap Koordinatları): " + cellPosition);
                      sendClickRequest(cellPosition);
                      }
                  }
              }
        if(end){
            EndGame(winnerPlayer);
        }
    }
    
    
    
  }

  public void EndGame(string winner){
        canvas.SetActive(false);
        grid.SetActive(false);
        playerNumText.SetText("");
        endGameCanvas.SetActive(true);
        if(int.Parse(winner)!=playerNum)
          winnerText.SetText("You Win");
        else if(int.Parse(winner)==playerNum)
          winnerText.SetText("You Lose");
  }
  public async void FindMatch(){
    Debug.Log("Finding");
    var matchmakingTicket = await socket.AddMatchmakerAsync("*", 2, 2);
    var ticket = matchmakingTicket.Ticket;
  }

  private async void OnReceivedMatchmakerMatched(IMatchmakerMatched matchmakerMatched){
    var match = await socket.JoinMatchAsync(matchmakerMatched);
    Debug.Log("self:" + match.Self.SessionId ); 
    foreach(var user in match.Presences){
      Debug.Log("other: " + user.SessionId);
    }
    await socket.SendMatchStateAsync(match.Id, 112321, "bubenimmesajım");
    matchId = match.Id;
    matchFound = true;
  }

  public async void sendClickRequest(Vector3Int cellPosition){
    var state = new PositionState
{
    x = cellPosition.x,
    y = cellPosition.y,
};
    await socket.SendMatchStateAsync(matchId, 300, JsonUtility.ToJson(state));
    Debug.Log(state);
    Debug.Log(JsonUtility.ToJson(state));
  }

    void CreateGameBoard()
    {
        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                Vector3Int tilePosition = new Vector3Int(j-4, 3-i, 0);
                tilemap.SetTile(tilePosition, tiles[matrix[i, j]]);
            }
        }
    }
}
