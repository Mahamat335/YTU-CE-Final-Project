

function InitModule(ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, initializer: nkruntime.Initializer){
	logger.warn('hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii');
	initializer.registerMatch("match", {
		matchInit: MatchInit,
		matchJoinAttempt: MatchJoinAttempt,
		matchJoin: MatchJoin,
		matchLeave: MatchLeave,
		matchLoop: MatchLoop,
		matchSignal: MatchSignal,
		matchTerminate: MatchTerminate
	  });
	initializer.registerMatchmakerMatched(MatchmakerMatched);
}

  let gameBoard: number[][] = [];
  let playerTurn: number = 1;
  let numberOfPlayers: number = 0;
  
function createGameBoard() {
  for (let i = 0; i < 6; i++) {
    gameBoard[i] = [];
    for (let j = 0; j < 8; j++) {
      gameBoard[i][j] = 0; // Başlangıçta tüm değerler 0
    }
  }
  gameBoard[0][0] = 1;
	gameBoard[5][7] = 4;
}
function MatchmakerMatched(context: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, matches: nkruntime.MatchmakerResult[] ): string {
	matches.forEach(function (match) {
	  logger.warn("Matched user '%s' named '%s'", match.presence.userId, match.presence.username);
	  Object.keys(match.properties).forEach(function (key) {
		logger.warn("Matched on '%s' value '%v'", key, match.properties[key])
	  });
	});
  
	try {
	  const matchId = nk.matchCreate("match");
	  return matchId;
	} catch (err) {
	  logger.warn('errorrrrrrrrrrrrrrrr');
	  throw (err);
	}
  }
const MatchInit = function (ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, params: {[key: string]: string}): {state: nkruntime.MatchState, tickRate: number, label: string} {
	logger.warn('Lobby match createdddddddddddddddddddddddddddddddddd');
	createGameBoard();
	return {
	  state: { matrix: gameBoard,
			   playerTurn: playerTurn,

			    },
	  tickRate: 10,
	  label: ""
	};
  };
const MatchLoop = function (ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, dispatcher: nkruntime.MatchDispatcher, tick: number, state: nkruntime.MatchState, messages: nkruntime.MatchMessage[]) : { state: nkruntime.MatchState} | null {

  
	let opCode = 1;
	let message = JSON.stringify(state.matrix);
	let presences = null; // Send to all.
	let sender = null; // Used if a message should come from a specific user.
	dispatcher.broadcastMessage(opCode, message, presences, sender, true);

	state.matrix = gameBoard;

	 opCode = 2;
	 message = JSON.stringify(playerTurn);
	 presences = null; 
	 sender = null; 
	dispatcher.broadcastMessage(opCode, message, presences, sender, true);

	for (const message of messages) {
		if(message.opCode == 300){
const payload = JSON.parse(nk.binaryToString(message.data));
			logger.warn("%v", message);
			logger.warn(payload.x.toString());
			logger.warn(payload.y.toString());
			move(payload.x, payload.y);
			
		}
	}
	opCode = 1;
	message = JSON.stringify(state.matrix);
	presences = null; 
	sender = null; 
	dispatcher.broadcastMessage(opCode, message, presences, sender, true);

	state.matrix = gameBoard;

	 opCode = 2;
	 message = JSON.stringify(playerTurn);
	 presences = null; 
	 sender = null; 
	dispatcher.broadcastMessage(opCode, message, presences, sender, true);

	let endGameCheck = checkEndGame();
	logger.warn(endGameCheck.toString());
	if(endGameCheck>0){
		opCode = 88;
	 	message = JSON.stringify(endGameCheck);
	 	presences = null;
		sender = null; 
		dispatcher.broadcastMessage(opCode, message, presences, sender, true);
	}
		

	return {
	  state
	};
  }
  let move = function(x: number, y: number){
	if(playerTurn == 1){
		if(gameBoard[y][x] == 0){
			gameBoard[y][x] = 1;
		}else{
			spread1(x, y, gameBoard[y][x]);
		}
		playerTurn = 2;
	}else{
		if(gameBoard[y][x] == 0){
			gameBoard[y][x] = 4;
		}else{
			spread2(x, y, gameBoard[y][x]);
		}
		playerTurn = 1;
	}
				
	
  }

  let checkEndGame = function(){
	let player1 = true, player2 = true;
	for(let i = 0; i< 6; i++){
		for(let j = 0; j<8; j++){
			if(gameBoard[i][j]==0){
				
			}else if(gameBoard[i][j]<4){
				player1 = false;
			}else if(gameBoard[i][j]<7){
				player2 = false;
			}
		}
	}
	
	if(player1){
		return 1;}else if(player2){
			return 2;
		}else {
			return 0;
		}
		
		
  }
  let spread1 = function(x: number, y: number, value: number){
	let direction = Math.floor(Math.random()*4);
	if(value>3)
		value-=3;
	gameBoard[y][x] = 0;
	if(value==1){
		if(direction == 0){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}
				
			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}
				
			} else if (direction == 1){
				if(y==5){
					gameBoard[y][x]++;
				}else{
					if(gameBoard[y+1][x]>3){
						gameBoard[y+1][x]-=3;
					}
					if(gameBoard[y+1][x]==3)
						spread1(x, y+1, 3);
					else
						gameBoard[y+1][x]++;
				}

				if(x == 0){
					gameBoard[y][x]++;
				}else{
					if(gameBoard[y][x-1]>3){
						gameBoard[y][x-1]-=3;
					}
					if(gameBoard[y][x-1]==3)
						spread1(x-1, y, 3);
					else
						gameBoard[y][x-1]++;
				}
			} else if (direction == 2){
				if(y==0){
					gameBoard[y][x]++;
				}else{
					if(gameBoard[y-1][x]>3){
						gameBoard[y-1][x]-=3;
					}
					if(gameBoard[y-1][x]==3)
						spread1(x, y+1, 3);
					else
						gameBoard[y-1][x]++;
				}

				if(x == 0){
					gameBoard[y][x]++;
				}else{
					if(gameBoard[y][x-1]>3){
						gameBoard[y][x-1]-=3;
					}
					if(gameBoard[y][x-1]==3)
						spread1(x-1, y, 3);
					else
						gameBoard[y][x-1]++;
				}
			} else{
				if(x == 7){
					gameBoard[y][x]++;
				}else{
					if(gameBoard[y][x+1]>3){
						gameBoard[y][x+1]-=3;
					}
					if(gameBoard[y][x+1]==3)
						spread1(x+1, y, 3);
					else
						gameBoard[y][x+1]++;
				}
					
				if(y==0){
					gameBoard[y][x]++;
				}else{
					if(gameBoard[y-1][x]>3){
						gameBoard[y-1][x]-=3;
					}
					if(gameBoard[y-1][x]==3)
						spread1(x, y-1, 3);
					else
						gameBoard[y-1][x]++;
				}
			}

	}else if(value==2){
		if(direction == 0){

			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]>3){
					gameBoard[y][x-1]-=3;
				}
				if(gameBoard[y][x-1]==3)
					spread1(x-1, y, 3);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]>3){
					gameBoard[y-1][x]-=3;
				}
				if(gameBoard[y-1][x]==3)
					spread1(x, y-1, 3);
				else
					gameBoard[y-1][x]++;
			}

		} else if(direction == 1){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}

			if(x == 0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]>3){
					gameBoard[y][x-1]-=3;
				}
				if(gameBoard[y][x-1]==3)
					spread1(x-1, y, 3);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]>3){
					gameBoard[y-1][x]-=3;
				}
				if(gameBoard[y-1][x]==3)
					spread1(x, y-1, 3);
				else
					gameBoard[y-1][x]++;
			}

		} else if(direction == 2){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}

			if(y==0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]>3){
					gameBoard[y-1][x]-=3;
				}
				if(gameBoard[y-1][x]==3)
					spread1(x, y-1, 3);
				else
					gameBoard[y-1][x]++;
			}

		} else if(direction == 3){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]>3){
					gameBoard[y][x-1]-=3;
				}
				if(gameBoard[y][x-1]==3)
					spread1(x-1, y, 3);
				else
					gameBoard[y][x-1]++;
			}

		}
	}
	else if(value==3){
		if(direction == 0){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]>3){
					gameBoard[y][x-1]-=3;
				}
				if(gameBoard[y][x-1]==3)
					spread1(x-1, y, 3);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]>3){
					gameBoard[y-1][x]-=3;
				}
				if(gameBoard[y-1][x]==3)
					spread1(x, y-1, 3);
				else
					gameBoard[y-1][x]++;
			}

		}else if(direction == 1){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]>3){
					gameBoard[y][x-1]-=3;
				}
				if(gameBoard[y][x-1]==3)
					spread1(x-1, y, 3);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]>3){
					gameBoard[y-1][x]-=3;
				}
				if(gameBoard[y-1][x]==3)
					spread1(x, y-1, 3);
				else
					gameBoard[y-1][x]++;
			}

		}else if(direction == 2){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]>3){
					gameBoard[y][x-1]-=3;
				}
				if(gameBoard[y][x-1]==3)
					spread1(x-1, y, 3);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]>3){
					gameBoard[y-1][x]-=3;
				}
				if(gameBoard[y-1][x]==3)
					spread1(x, y-1, 3);
				else
					gameBoard[y-1][x]++;
			}

		}else if(direction == 3){
			if(x == 7){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]>3){
					gameBoard[y][x+1]-=3;
				}
				if(gameBoard[y][x+1]==3)
					spread1(x+1, y, 3);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]>3){
					gameBoard[y+1][x]-=3;
				}
				if(gameBoard[y+1][x]==3)
					spread1(x, y+1, 3);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]>3){
					gameBoard[y][x-1]-=3;
				}
				if(gameBoard[y][x-1]==3)
					spread1(x-1, y, 3);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]>3){
					gameBoard[y-1][x]-=3;
				}
				if(gameBoard[y-1][x]==3)
					spread1(x, y-1, 3);
				else
					gameBoard[y-1][x]++;
			}

		}
	}
  }
  let spread2 = function(x: number, y: number, value: number){
	let direction = Math.floor(Math.random()*4);
	if(value<=3)
		value+=3;
	gameBoard[y][x] = 0;
	if(value==4){
		if(direction == 0){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}
				
			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}
				
			} else if (direction == 1){
				if(y==5){
					if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
				}else{
					if(gameBoard[y+1][x]<=3){
						gameBoard[y+1][x]+=3;
					}
					if(gameBoard[y+1][x]==6)
						spread2(x, y+1, 6);
					else
						gameBoard[y+1][x]++;
				}

				if(x == 0){
					if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
				}else{
					if(gameBoard[y][x-1]<=3){
						gameBoard[y][x-1]+=3;
					}
					if(gameBoard[y][x-1]==6)
						spread2(x-1, y, 6);
					else
						gameBoard[y][x-1]++;
				}
			} else if (direction == 2){
				if(y==0){
					if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
				}else{
					if(gameBoard[y-1][x]<=3){
						gameBoard[y-1][x]+=3;
					}
					if(gameBoard[y-1][x]==6)
						spread2(x, y+1, 6);
					else
						gameBoard[y-1][x]++;
				}

				if(x == 0){
					if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
				}else{
					if(gameBoard[y][x-1]<=3){
						gameBoard[y][x-1]+=3;
					}
					if(gameBoard[y][x-1]==6)
						spread2(x-1, y, 6);
					else
						gameBoard[y][x-1]++;
				}
			} else{
				if(x == 7){
					if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
				}else{
					if(gameBoard[y][x+1]<=3){
						gameBoard[y][x+1]+=3;
					}
					if(gameBoard[y][x+1]==6)
						spread2(x+1, y, 6);
					else
						gameBoard[y][x+1]++;
				}
					
				if(y==0){
					if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
				}else{
					if(gameBoard[y-1][x]<=3){
						gameBoard[y-1][x]+=3;
					}
					if(gameBoard[y-1][x]==6)
						spread2(x, y-1, 6);
					else
						gameBoard[y-1][x]++;
				}
			}

	}else if(value==5){
		if(direction == 0){

			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]<=3){
					gameBoard[y][x-1]+=3;
				}
				if(gameBoard[y][x-1]==6)
					spread2(x-1, y, 6);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]<=3){
					gameBoard[y-1][x]+=3;
				}
				if(gameBoard[y-1][x]==6)
					spread2(x, y-1, 6);
				else
					gameBoard[y-1][x]++;
			}

		} else if(direction == 1){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}

			if(x == 0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]<=3){
					gameBoard[y][x-1]+=3;
				}
				if(gameBoard[y][x-1]==6)
					spread2(x-1, y, 6);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]<=3){
					gameBoard[y-1][x]+=3;
				}
				if(gameBoard[y-1][x]==6)
					spread2(x, y-1, 6);
				else
					gameBoard[y-1][x]++;
			}

		} else if(direction == 2){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}

			if(y==0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]<=3){
					gameBoard[y-1][x]+=3;
				}
				if(gameBoard[y-1][x]==6)
					spread2(x, y-1, 6);
				else
					gameBoard[y-1][x]++;
			}

		} else if(direction == 3){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]<=3){
					gameBoard[y][x-1]+=3;
				}
				if(gameBoard[y][x-1]==6)
					spread2(x-1, y, 6);
				else
					gameBoard[y][x-1]++;
			}

		}
	}
	else if(value==6){
		if(direction == 0){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]<=3){
					gameBoard[y][x-1]+=3;
				}
				if(gameBoard[y][x-1]==6)
					spread2(x-1, y, 6);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]<=3){
					gameBoard[y-1][x]+=3;
				}
				if(gameBoard[y-1][x]==6)
					spread2(x, y-1, 6);
				else
					gameBoard[y-1][x]++;
			}

		}else if(direction == 1){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]<=3){
					gameBoard[y][x-1]+=3;
				}
				if(gameBoard[y][x-1]==6)
					spread2(x-1, y, 6);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]<=3){
					gameBoard[y-1][x]+=3;
				}
				if(gameBoard[y-1][x]==6)
					spread2(x, y-1, 6);
				else
					gameBoard[y-1][x]++;
			}

		}else if(direction == 2){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]<=3){
					gameBoard[y][x-1]+=3;
				}
				if(gameBoard[y][x-1]==6)
					spread2(x-1, y, 6);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]<=3){
					gameBoard[y-1][x]+=3;
				}
				if(gameBoard[y-1][x]==6)
					spread2(x, y-1, 6);
				else
					gameBoard[y-1][x]++;
			}

		}else if(direction == 3){
			if(x == 7){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x+1]<=3){
					gameBoard[y][x+1]+=3;
				}
				if(gameBoard[y][x+1]==6)
					spread2(x+1, y, 6);
				else
					gameBoard[y][x+1]++;
			}

			if(y==5){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y+1][x]<=3){
					gameBoard[y+1][x]+=3;
				}
				if(gameBoard[y+1][x]==6)
					spread2(x, y+1, 6);
				else
					gameBoard[y+1][x]++;
			}

			if(x == 0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y][x-1]<=3){
					gameBoard[y][x-1]+=3;
				}
				if(gameBoard[y][x-1]==6)
					spread2(x-1, y, 6);
				else
					gameBoard[y][x-1]++;
			}

			if(y==0){
				if(gameBoard[y][x]==0){gameBoard[y][x]=3;}gameBoard[y][x]++;
			}else{
				if(gameBoard[y-1][x]<=3){
					gameBoard[y-1][x]+=3;
				}
				if(gameBoard[y-1][x]==6)
					spread2(x, y-1, 6);
				else
					gameBoard[y-1][x]++;
			}

		}
	}
  }
  
  const MatchJoin = function (ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, dispatcher: nkruntime.MatchDispatcher, tick: number, state: nkruntime.MatchState, presence: nkruntime.Presence[]) : { state: nkruntime.MatchState } | null {
	numberOfPlayers++;
	const opCode = 1111;
	const message = JSON.stringify(numberOfPlayers);
	const presences = presence; 
	const sender = null; 
	dispatcher.broadcastMessage(opCode, message, presences, sender, true);
	return {
	  state
	};
  }
  
  const MatchLeave = function (ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, dispatcher: nkruntime.MatchDispatcher, tick: number, state: nkruntime.MatchState, presences: nkruntime.Presence[]) : { state: nkruntime.MatchState } | null {
	presences.forEach(function (p) {
	  delete(state.presences[p.sessionId]);
	});
  
	return {
	  state
	};
  }
  

  const MatchJoinAttempt: nkruntime.MatchJoinAttemptFunction = function (ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, dispatcher: nkruntime.MatchDispatcher, tick: number, state: nkruntime.MatchState, presence: nkruntime.Presence, metadata: {[key: string]: any }) {
	
	let accept = true;
	return {
		state,
		accept
	};
  };

  const MatchTerminate: nkruntime.MatchTerminateFunction = function (ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, dispatcher: nkruntime.MatchDispatcher, tick: number, state: nkruntime.MatchState, graceSeconds: number) {
	return {
		state
	};
  };
  
  const MatchSignal: nkruntime.MatchSignalFunction = function (ctx: nkruntime.Context, logger: nkruntime.Logger, nk: nkruntime.Nakama, dispatcher: nkruntime.MatchDispatcher, tick: number, state: nkruntime.MatchState, data: string) {
	return {
		state,
		data
	};
  };